@extends('frontend.layout')
@section('title','YNetPla')
@section('css')
    <style type="text/css">
        #content-main {
          /* necessary to hide collapsed sidebar */
          overflow-x: hidden;
        }

        #content-inner {
          /* for the animation */
          transition: width 0.3s ease;
          padding-bottom: 30px;
        }
        #sidebar {
          /* for the animation */
          transition: margin 0.3s ease;
        }
    </style>
@stop
@section('content')
<div class="container-fluid books-banner search-books-section-edit" style="background-image: url('../frontend/img/books-banner.png');">
    <form action="{{URL('popular-'.Request::segment(1))}}" method="get" class="form">
        <input name="keywords" type="text" value="{!! $keywords != '' ? $keywords : '' !!}" placeholder="Search {!! Request::segment(1) == 'movies' ? 'Movies' : 'TV Series' !!}">
        <button><i class="fa fa-search"></i></button>
    </form>
</div>
<div class="container-fluid search-books-section" style="background-image: url('../frontend/img/top-book-section.png');">
    <div class="clearfix" style="min-height: 70px;">
        <button id="toggle-right-sidebar">VIEW SCHEDULES</button>
    </div>
    <div class="container">
        <div class="row" id="content-main">
            <div id="content-inner" class="col-md-12">
                <div id="videotitle" class="collapse">
                    <h2>VIDEO TITLE</h2>
                </div>
                <div id="left-part" class="col-md-5">
                    <div class="tv-series-bg">
                        <div id="imgholdertv" class="img-holder-tv">
                        <div id="shadow" class="shadow-inset" style="background-image: url('{{$details->getPosterPath() == '' ? $settings->avatar : '//image.tmdb.org/t/p/original'.$details->getPosterPath() }}');"></div>
                        </div>
                    </div>
                    <div id="episodesholder" class="episodes-holder">
                        <h2>Season 1: Episodes</h2>
                        <div class="episode-name">
                            <h3>Episode Names</h3>
                        </div>
                        <div class="episode-list">
                            <ul>
                                <li>Episode 2: <span>The Weirdo on Maple Street</span></li>
                                <li>Episode 3: <span>Holly, Jolly</span></li>
                                <li>Episode 4: <span>The Body</span></li>
                                <li>Episode 5: <span>The Flea and the Acrobat</span></li>
                                <li>Episode 6: <span>The Monster</span></li>
                                <li>Episode 7: <span>The Bathtub</span></li>
                                <li>Episode 8: <span>The Upside Down</span></li>
                                <li>Episode 9: <span>The Weirdo on Maple Street</span></li>
                            </ul>
                            <div class="episodes-arrow">
                                <ul>
                                    <li><i class="fa fa-angle-left"></i></li>
                                    <li><i class="fa fa-angle-right"></i></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="center-part" class="col-md-7">
                    <div class="movie-title">
                        @if(Request::segment(1) == 'tv-series')
                        <h2>{{$details->getOriginalName()}}: Season {{$details->getNumberOfSeasons()}} Episode {{count($season->getEpisodes())}}</h2>
                        <h3>{{$details->getOriginalName()}} Trailer:</h3>
                        @else
                        <h2>{{$details->getTitle()}}</h2>
                        <h3>{{$details->getTitle()}} Trailer:</h3>
                        @endif
                        <div class="movie-holder">
                            <?php $video_link= ''; $genres= '';?>
                            @foreach($details->getVideos() as $video)
                                <?php $video_link = $video->getKey(); ?>
                            @endforeach
                            @if(!$video_link)
                                <?php $video_link = 'bkifvuuIrXs'; ?>
                            @endif
                            @foreach($details->getGenres() as $genre)
                                <?php $genres = $genre->getName().' '; ?>
                            @endforeach
                            @if(!$genres)
                                <?php $genres = 'No Genre'; ?>
                            @endif
                        <iframe src="https://www.youtube.com/embed/{{$video_link}}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen class="movie-play" id="movieplay"></iframe>
                        </div>

                        <div id="movieinfoholder">
                            @if(Request::segment(1) == 'tv-series')    
                            <h3>{{substr(get_object_vars($details->getFirstAirDate())['date'], 0, 4)}}<br>{{$genres}}</h3>
                            @else
                            <h3>{{substr(get_object_vars($details->getReleaseDate())['date'], 0, 4)}}<br>{{$genres}}</h3>
                            @endif
                            <div class="movie-des">
                                <p>{{$details->getOverview()}}</p>
                            </div>
                        </div>
                    
                        {{-- <div class="link-ep">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6">
                                <div class="num-pos">
                                    <h3>Episodes</h3>
                                    <ul class="episode-num">
                                        <li><i class="fa fa-chevron-left"></i></li>
                                        <li class="active">1</li>
                                        <li>2</li>
                                        <li>3</li>
                                        <li>4</li>
                                        <li>5</li>
                                        <li>6</li>
                                        <li>7</li>
                                        <li>8</li>
                                        <li>9</li>
                                        <li>10</li>
                                        <li><i class="fa fa-chevron-right"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div> --}}
                    </div>
                </div>
            </div>

            <div id="viewschedule" class="view-schedule">
                <button id="schedule">VIEW DETAILED SCHEDULE</button>
            </div>

            <div id="sidebar" class="col-md-3 collapse">
                <div class="sidebar-bg">
                    <h2>Schedule for<br><span>August 8</span></h2>
                    <div class="h3-bg">
                        <h3>20:00</h3>
                    </div>
                    <div class="sched-bg">
                        <div class="row">
                            <div class="col-md-4">
                                <h3>20:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>Stranger Things<br><span>Lorem</span></h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <h3>20:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>Game of Thrones<br><span>Lorem</span></h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <h3>20:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>The Fall<br><span>Lorem</span></h4>
                            </div>
                        </div>
                    </div>
                    <div class="h3-bg">
                        <h3>21:00</h3>
                    </div>
                    <div class="sched-bg">
                        <div class="row">
                            <div class="col-md-4">
                                <h3>21:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>The Big Bang Theory<br><span>Lorem</span></h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <h3>21:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>Jessica Jones<br><span>Lorem</span></h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <h3>21:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>The Terror<br><span>Lorem</span></h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <h3>21:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>Black Lightning<br><span>Lorem</span></h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <h3>21:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>Instinct<br><span>Lorem</span></h4>
                            </div>
                        </div>
                    </div>
                    <div class="h3-bg">
                        <h3>22:00</h3>
                    </div>
                    <div class="sched-bg">
                        <div class="row">
                            <div class="col-md-4">
                                <h3>22:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>Deception<br><span>Lorem</span></h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <h3>22:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>Barry<br><span>Lorem</span></h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <h3>22:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>Krypton<br><span>Lorem</span></h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <h3>22:00<br><span>Lorem</span></h3> 
                            </div>
                            <div class="col-md-8">
                                <h4>Knights of the Zodiac<br><span>Lorem</span></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- <section class="sec1-series">
    <div class="sec1-series-content1" style="background-image: url('../frontend/img/tv-series.jpg');">
        <div class="container">
            <div class="row">
                <h2>Editor's Choice</h2>
                <div class="sec1-series-content2">
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/editor-1.png">
                            </div>
                            <h3>DEADPOOL 2</h3>
                            <h4>2018</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/editor-2.png">
                            </div>
                            <h3>ant man and the wasp</h3>
                            <h4>2018</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/editor-3.png">
                            </div>
                            <h3>uncle drew</h3>
                            <h4>2018</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/editor-4.png">
                            </div>
                            <h3>justice league</h3>
                            <h4>2018</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="btn-soon-holder">
        <button class="btn-coming-soon">coming soon movies</button>
    </div>
</section> --}}

<section class="sec2-series">
    <div class="sec2-series-bg" style="background-image: url('../frontend/img/tv-series.jpg');">
        <div class="container">
           <div class="row">
                <h2>Cast</h2>
                    <div class="sec2-series-content1">
                        <div class="slider-area">
                            <div class="owl-carousel owl-theme">
                                <div class="item">
                                    <div class="center-position">
                                       <div class="box-shadow-cast">
                                            <img src="../frontend/img/cast-1.png">
                                        </div>
                                        <h2>Millie Bobby Brown</h2>
                                        <h3><span>as</span> Eleven</h3> 
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="center-position">
                                        <div class="box-shadow-cast">
                                            <img src="../frontend/img/cast-2.png">
                                        </div>
                                        <h2>Finn Wolfhard</h2>
                                        <h3><span>as</span> Mike</h3>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="center-position">
                                        <div class="box-shadow-cast">
                                            <img src="../frontend/img/cast-3.png">
                                        </div>
                                        <h2>Noah Schnapp</h2>
                                        <h3><span>as</span> Will</h3>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="center-position">
                                        <div class="box-shadow-cast">
                                            <img src="../frontend/img/cast-4.png">
                                        </div>
                                        <h2>Gaten Matarazzo</h2>
                                        <h3><span>as</span> Dustin</h3>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="center-position">
                                        <div class="box-shadow-cast">
                                            <img src="../frontend/img/cast-5.png">
                                        </div>
                                        <h2>Caleb McLaughlin</h2>
                                        <h3><span>as</span> Lucas</h3>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="center-position">
                                       <div class="box-shadow-cast">
                                            <img src="../frontend/img/cast-1.png">
                                        </div>
                                        <h2>Millie Bobby Brown</h2>
                                        <h3><span>as</span> Eleven</h3> 
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="center-position">
                                        <div class="box-shadow-cast">
                                            <img src="../frontend/img/cast-2.png">
                                        </div>
                                        <h2>Finn Wolfhard</h2>
                                        <h3><span>as</span> Mike</h3>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="center-position">
                                        <div class="box-shadow-cast">
                                            <img src="../frontend/img/cast-3.png">
                                        </div>
                                        <h2>Noah Schnapp</h2>
                                        <h3><span>as</span> Will</h3>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="center-position">
                                        <div class="box-shadow-cast">
                                            <img src="../frontend/img/cast-4.png">
                                        </div>
                                        <h2>Gaten Matarazzo</h2>
                                        <h3><span>as</span> Dustin</h3>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="center-position">
                                        <div class="box-shadow-cast">
                                            <img src="../frontend/img/cast-5.png">
                                        </div>
                                        <h2>Caleb McLaughlin</h2>
                                        <h3><span>as</span> Lucas</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>

<section class="sec3-series" id="sec3-series">
    <div class="sec3-series-content1" style="background-image: url('../frontend/img/top-book-section.png');">
        <div class="container">
            <div class="row">
                <h2>Editor's Choice</h2>
                <div class="sec3-series-content2">
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/toppick-1.png">
                            </div>
                            <h3>Jessica jones</h3>
                            <h4>2017</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/toppick-2.png">
                            </div>
                            <h3>Knights of the zodiac</h3>
                            <h4>2018</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/toppick-3.png">
                            </div>
                            <h3>Krypton</h3>
                            <h4>2018</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/toppick-4.png">
                            </div>
                            <h3>Sherlock</h3>
                            <h4>2010</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="sec4-series" id="sec4-series">
    <div class="sec4-series-content1" style="background-image: url('../frontend/img/tv-series.jpg');">
        <div class="container">
            <div class="row">
                <h2>Popular Shows Airing Tonight</h2>
                <div class="sec4-series-content2">
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/popular-1.png">
                            </div>
                            <h3>Instinct</h3>
                            <h4>2018</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/popular-2.png">
                            </div>
                            <h3>Deception</h3>
                            <h4>2018</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/popular-3.png">
                            </div>
                            <h3>Barry</h3>
                            <h4>2018</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="center-position2">
                            <div class="box-shadow-editor">
                                <img src="../frontend/img/popular-4.png">
                            </div>
                            <h3>Black Lightning</h3>
                            <h4>2018</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@stop
@section('js')
<script type="text/javascript">

    $('#toggle-right-sidebar').click(function(){
        $("#sidebar").toggleClass("collapse");
        $("#videotitle").toggleClass("collapse");
        $("#content-inner").toggleClass("col-md-12 col-md-9", 500);
        $("#left-part").css("padding-right", "30px");
        $("#left-part").css("padding-left", "30px");
        $("#center-part").css("padding-left", "0px");
        $("#center-part").css("padding-right", "0px");
        $("#sidebar").css("padding-right", "0px");
        $("#sidebar").css("padding-left", "0px");
    });

     $('#schedule').click(function(){
        window.location.replace('{{URL('/schedule')}}');
    });

    $( function() {
    var state = true;
    $( "#toggle-right-sidebar" ).on( "click", function() {
      if ( state ) {
        $( "#shadow" ).animate({
          height: 445
        }, 1000 );

        $( "#imgholdertv" ).animate({
          height: 479
        }, 1000 );

        $( "#movieplay" ).animate({
          height: 330
        }, 1000 );

        $( "#movieinfoholder" ).animate({
          marginTop: '-65px'
        }, 1000 );

       $("#toggle-right-sidebar").prop('value', 'Hide');

        document.getElementById('episodesholder').style.display = 'block';
        document.getElementById('viewschedule').style.display = 'block';

        $(this).html('HIDE SCHEDULES');
      } 
       else {
        $( "#shadow" ).animate({
          height: 621
        }, 1000 );

        $( "#imgholdertv" ).animate({
          height: 655
        }, 1000 );

        $( "#movieplay" ).animate({
          height: 392
        }, 1000 );

        $( "#movieinfoholder" ).animate({
          marginTop: '0px'
        }, 1000 );

        document.getElementById('episodesholder').style.display = 'none';
        document.getElementById('viewschedule').style.display = 'none';

        $(this).html('VIEW SCHEDULES');
      }      
      state = !state;
    });

   

  } );

     var owl = $('.slider-area .owl-carousel');
            owl.owlCarousel({
               
                nav: true,
                autoplay:false,
                navText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
               
                loop: true,
                responsive: {
                    0: {
                        items: 1,
                        loop: false
                    },
                    767:{
                        items:3,
                        loop: false
                    },
                    1000: {
                        items: 5,
                        nav: true,
                        autoplay:true,
                        loop: false
                    }
                }
            });
</script>
@stop
